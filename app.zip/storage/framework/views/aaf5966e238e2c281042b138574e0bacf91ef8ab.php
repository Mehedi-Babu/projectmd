<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Mail Body</title>
</head>

<body>

    <p>Hi, <?php echo e($data['name_three']); ?>.</p>
    <p>UserName: <?php echo e($data['emes']); ?>.</p>
    <p>Your Password <?php echo e($data['pass_three']); ?></p>
    <p>Login Url Please Click <a href="<?php echo e(route('login')); ?>">Click Me</a>.</p>
    <p>Thank your for registration.</p>
    <p>simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book</p>

</body>

</html>
<?php /**PATH D:\wamp64\www\over the wall - laravel\resources\views/client-site/mail/mail_body_three.blade.php ENDPATH**/ ?>