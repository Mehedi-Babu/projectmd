

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <h2 style="text-align: center;color:green">Welcome to New Dashboard</h2>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\over the wall - laravel\resources\views/backend/main.blade.php ENDPATH**/ ?>