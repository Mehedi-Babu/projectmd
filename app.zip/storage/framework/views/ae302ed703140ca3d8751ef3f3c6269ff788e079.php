<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Over The Wall</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'>
    <link rel="stylesheet" href="<?php echo e(asset('client/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('toastr.min.css')); ?>">

</head>

<body>
    <!-- partial:index.partial.html -->
    <!-- MultiStep Form -->
    <?php echo $__env->yieldContent('content'); ?>
    <!-- /.MultiStep Form -->
    <!-- partial -->
    <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
    <script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js'></script>
    <script src="<?php echo e(asset('client/script.js')); ?>"></script>
    <script src="<?php echo e(asset('toastr.min.js')); ?>"></script>

    <?php echo $__env->yieldContent('footer'); ?>

    <script type="text/javascript">
        <?php if(Session::has('message')): ?>

            var type = "<?php echo e(Session::get('alert-type', 'success')); ?>";

            switch (type) {
                case "success":
                    toastr.success("<?php echo e(Session::get('message')); ?>");
                    break;
                case "error":
                    toastr.error("<?php echo e(Session::get('message')); ?>");
                    break;
            }
        <?php endif; ?>
    </script>

</body>

</html>
<?php /**PATH D:\wamp64\www\over the wall - laravel\resources\views/client-site/master.blade.php ENDPATH**/ ?>