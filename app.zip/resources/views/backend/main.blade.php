@extends('backend.master')

@section('content')
    <div class="row">
        <div class="col-md-12">
            <h2 style="text-align: center;color:green">Welcome to New Dashboard</h2>
        </div>
    </div>
@endsection
