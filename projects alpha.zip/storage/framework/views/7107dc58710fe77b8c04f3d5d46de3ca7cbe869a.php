<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-6 col-md-offset-3">

            <form method="POST" action="<?php echo e(route('register')); ?>" id="msform">
                <?php echo csrf_field(); ?>
                <!-- progressbar -->
                <ul id="progressbar">
                    <li class="active">Team Details</li>
                    <li>University Details</li>
                    <li>Team Member's Details</li>


                </ul>
                <!-- fieldsets -->
                <fieldset>
                    <h2 class="fs-title">Team Details</h2>
                    <h3 class="fs-subtitle">Tell us something more about your team</h3>
                    <input type="text" class="<?php $__errorArgs = ['team_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('team_name')); ?>"
                        name="team_name" placeholder="Team Name" required autocomplete="team_name" autofocus
                        id="team_name" />
                    <?php $__errorArgs = ['team_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <input type="text" name="team_leader_name" id="team_leader_name"
                        class="<?php $__errorArgs = ['team_leader_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('team_leader_name')); ?>"
                        placeholder="Team Leader's Name" required autocomplete="team_leader_name" autofocus />

                    <?php $__errorArgs = ['team_leader_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                    <input type="email" name="email" id="email" class="<?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        value="<?php echo e(old('email')); ?>" placeholder="Email Address" required autocomplete="email" autofocus />

                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                    <input type="tel" name="phone" id="phone" class="<?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        value="<?php echo e(old('phone')); ?>" placeholder="Phone Number" required autocomplete="phone" autofocus />

                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>



                    <input type="text" name="linkedin" id="linkedin" class="<?php $__errorArgs = ['linkedin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        value="<?php echo e(old('linkedin')); ?>" placeholder="Team Leader's Linkedin Profile" required
                        autocomplete="linkedin" autofocus />

                    <?php $__errorArgs = ['linkedin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <input type="button" name="next" id="first" disabled class="next action-button"
                        value="Next" />
                </fieldset>
                <fieldset>
                    <h2 class="fs-title">University Details</h2>
                    <h3 class="fs-subtitle"></h3>



                    <label for="standard-select" class="select-label">What university are you from?</label>
                    <div class="select">
                        <select id="standard-select" name="what_uni_from"
                            class="<?php $__errorArgs = ['what_uni_from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                            <option value="Option 1">Option 1</option>
                            <option value="Option 2">Option 2</option>
                            <option value="Option 3">Option 3</option>
                            <option value="Option 4">Option 4</option>
                            <option value="Option 5">Option 5</option>
                            <option value="Option length">
                                Option that has too long of a value to fit
                            </option>
                        </select>
                        <?php $__errorArgs = ['what_uni_from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>



                    <input type="text" name="uni_id_number" id="uni_id_number"
                        class="<?php $__errorArgs = ['uni_id_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('uni_id_number')); ?>"
                        placeholder="What is your university ID number" required autocomplete="uni_id_number" autofocus />

                    <?php $__errorArgs = ['uni_id_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>



                    <input type="text" name="uni_department" id="uni_department"
                        class="<?php $__errorArgs = ['uni_department'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('uni_department')); ?>"
                        placeholder="What is your department" required autocomplete="uni_department" autofocus />

                    <?php $__errorArgs = ['uni_department'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                    <label for="standard-select" class="select-label">What year of studies are you in</label>
                    <div class="select">
                        <select id="standard-select" name="what_year_of_studires"
                            class="<?php $__errorArgs = ['what_year_of_studires'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <option value="1'st Year">1'st Year</option>
                            <option value="2'nd Yea">2'nd Year</option>
                            <option value="3'rd Year">3'rd Year</option>
                            <option value="4'th Year">4'th Year</option>
                            <option value="5'th Year">5'th Year</option>
                            <option value="graduate">Graduate</option>

                        </select>
                        <?php $__errorArgs = ['what_year_of_studires'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>


                    <label for="standard-select" class="select-label">When are you expecting to graduate?</label>
                    <div class="select">
                        <select id="standard-select" name="when_are_you_expecting_graduate"
                            class="<?php $__errorArgs = ['when_are_you_expecting_graduate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                            <?php for($i = 2022; $i <= 2040; $i++): ?>
                                <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                            <?php endfor; ?>


                        </select>
                        <?php $__errorArgs = ['when_are_you_expecting_graduate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <label for="standard-select" class="select-label">How many members are in the team, including
                        yourself?</label>
                    <div class="select">
                        <select id="standard-select" name="how_many_member_team"
                            class="<?php $__errorArgs = ['how_many_member_team'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <option value="2">2 Members</option>
                            <option value="3">3 Members</option>

                        </select>
                        <?php $__errorArgs = ['how_many_member_team'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <input type="button" name="previous" class="previous action-button-previous" value="Previous" />
                    <input type="button" name="next" id="second_step" disabled class="next action-button"
                        value="Next" />
                </fieldset>
                <fieldset>
                    <h2 class="fs-title">Team Member's Details</h2>
                    <h3 class="fs-subtitle">2nd Team Member :</h3>

                    <input type="text" name="second_team_member_name" id="second_team_member_name"
                        class="<?php $__errorArgs = ['second_team_member_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        value="<?php echo e(old('second_team_member_name')); ?>" placeholder="2nd Team Member's Name" required
                        autocomplete="second_team_member_name" autofocus />

                    <?php $__errorArgs = ['second_team_member_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                    <input type="email" name="second_team_member_email" id="second_team_member_email"
                        class="<?php $__errorArgs = ['second_team_member_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        value="<?php echo e(old('second_team_member_email')); ?>" placeholder="2nd Team Member's email" required
                        autocomplete="second_team_member_email" autofocus />

                    <?php $__errorArgs = ['second_team_member_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                    <input type="tel" name="second_team_member_phone" id="second_team_member_phone"
                        class="<?php $__errorArgs = ['second_team_member_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        value="<?php echo e(old('second_team_member_phone')); ?>" placeholder="2nd Team Member's Phone Number"
                        required autocomplete="second_team_member_phone" autofocus />

                    <?php $__errorArgs = ['second_team_member_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <br>
                    <h3 class="fs-subtitle">3rd Team Member :</h3>

                    <input type="text" name="third_team_member_name" id="third_team_member_name"
                        class="<?php $__errorArgs = ['third_team_member_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        value="<?php echo e(old('third_team_member_name')); ?>" placeholder="3rd Team Member's Name"
                        autocomplete="third_team_member_name" autofocus />

                    <?php $__errorArgs = ['third_team_member_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <input type="email" name="third_team_member_email" id="third_team_member_email"
                        class="<?php $__errorArgs = ['third_team_member_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        value="<?php echo e(old('third_team_member_email')); ?>" placeholder="3nd Team Member's email"
                        autocomplete="third_team_member_email" autofocus />

                    <?php $__errorArgs = ['third_team_member_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <input type="tel" name="third_team_member_phone" id="third_team_member_phone"
                        class="<?php $__errorArgs = ['third_team_member_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        value="<?php echo e(old('third_team_member_phone')); ?>" placeholder="3rd Team Member's Phone Number"
                         autocomplete="third_team_member_phone" autofocus />

                    <?php $__errorArgs = ['third_team_member_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <input type="button" name="previous" class="previous action-button-previous" value="Previous" />
                    <button type="submit" disabled id="final" class="next action-button">Submit</button>
                </fieldset>

            </form>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <script>
        $(window).load(function() {
            $('#first').val('disabled');
            $('#team_name').css({
                'border': "1px solid red"
            })
            $('#team_leader_name').css({
                'border': "1px solid red"
            })

            $('#email').css({
                'border': "1px solid red"
            })

            $('#phone').css({
                'border': "1px solid red"
            })

            $('#linkedin').css({
                'border': "1px solid red"
            })

            //---------second form

            $('#second_step').val('disabled');
            $('#uni_id_number').css({
                'border': "1px solid red"
            })
            $('#uni_department').css({
                'border': "1px solid red"
            })


            //---------third form

            $('#final').text('disabled');

            $('#second_team_member_name').css({
                'border': "1px solid red"
            })
            $('#second_team_member_email').css({
                'border': "1px solid red"
            })

            $('#second_team_member_phone').css({
                'border': "1px solid red"
            })

//
//            $('#third_team_member_name').css({
//                'border': "1px solid red"
//            })
//            $('#third_team_member_email').css({
//                'border': "1px solid red"
//            })
//
//            $('#third_team_member_phone').css({
//                'border': "1px solid red"
//            })






        })

        var team_name;
        var team_leader_name;
        var email;
        var phone;
        var linkedin;

        $('#team_name').on('keyup', function() {
            var coun = $(this).val();
            if (coun.length > 0) {
                team_name = 1;
                $('#team_name').css({
                    'border': "1px solid silver"
                })

                verify_first();

            } else {
                $('#first').val('disabled');
                $('#first').attr('disabled');
                $('#team_name').css({
                    'border': "1px solid red"
                })
            }
        })

        $('#team_leader_name').on('keyup', function() {
            var coun = $(this).val();
            if (coun.length > 0) {
                team_leader_name = 1;

                $('#team_leader_name').css({
                    'border': "1px solid silver"
                })
                verify_first();

            } else {
                $('#first').val('disabled');
                $('#first').attr('disabled');
                $('#team_leader_name').css({
                    'border': "1px solid red"
                })
            }
        })

        $('#email').on('keyup', function() {
            var coun = $(this).val();
            if (coun.length > 0) {
                email = 1;

                $('#email').css({
                    'border': "1px solid silver"
                })
                verify_first();

            } else {
                $('#first').val('disabled');
                $('#first').attr('disabled');
                $('#email').css({
                    'border': "1px solid red"
                })
            }
        })


        $('#phone').on('keyup', function() {
            var coun = $(this).val();
            if (coun.length > 0) {
                phone = 1;

                $('#phone').css({
                    'border': "1px solid silver"
                })
                verify_first();
            } else {
                $('#first').val('disabled');
                $('#first').attr('disabled');
                $('#phone').css({
                    'border': "1px solid red"
                })
            }
        })

        $('#linkedin').on('keyup', function() {
            var coun = $(this).val();
            if (coun.length > 0) {
                linkedin = 1;
                $('#linkedin').css({
                    'border': "1px solid silver"
                })
                verify_first();
            } else {
                $('#first').val('disabled');
                $('#first').attr('disabled');
                $('#linkedin').css({
                    'border': "1px solid red"
                })
            }
        })

        function verify_first() {
            if (this.team_name == 1 && this.team_leader_name == 1 && this.email == 1 && this.phone == 1 && this
                .linkedin == 1) {
                $('#first').val('next');
                $('#first').removeAttr('disabled');

            }
        }

        //---------second form--

        var uni_id_number;
        var uni_department;

        $('#uni_id_number').on('keyup', function() {
            var coun = $(this).val();
            if (coun.length > 0) {
                uni_id_number = 1;
                $('#uni_id_number').css({
                    'border': "1px solid silver"
                })

                verify_second();

            } else {
                $('#second_step').val('disabled');
                $('#second_step').attr('disabled');
                $('#uni_id_number').css({
                    'border': "1px solid red"
                })
            }
        })

        $('#uni_department').on('keyup', function() {
            var coun = $(this).val();
            if (coun.length > 0) {
                uni_department = 1;

                $('#uni_department').css({
                    'border': "1px solid silver"
                })
                verify_second();

            } else {
                $('#second_step').val('disabled');
                $('#second_step').attr('disabled');
                $('#uni_department').css({
                    'border': "1px solid red"
                })
            }
        })

        function verify_second() {
            if (this.uni_id_number == 1 && this.uni_department == 1) {
                $('#second_step').val('next');
                $('#second_step').removeAttr('disabled');

            }
        }


        // third step--

        var second_team_member_name;
        var second_team_member_email;
        var second_team_member_phone;
//        var third_team_member_name;
//        var third_team_member_email;
//        var third_team_member_phone;

        $('#second_team_member_name').on('keyup', function() {
            var coun = $(this).val();
            if (coun.length > 0) {

                second_team_member_name = 1;
                $('#second_team_member_name').css({
                    'border': "1px solid silver"
                })

                verify_final();

            } else {

                $('#final').attr('disabled');
                $('#final').text('disabled');
                $('#second_team_member_name').css({
                    'border': "1px solid red"
                })
            }
        })

        $('#second_team_member_email').on('keyup', function() {
            var coun = $(this).val();
            if (coun.length > 0) {
                second_team_member_email = 1;
                $('#second_team_member_email').css({
                    'border': "1px solid silver"
                })

                verify_final();

            } else {
                $('#final').attr('disabled');
                $('#final').text('disabled');
                $('#second_team_member_email').css({
                    'border': "1px solid red"
                })
            }
        })

        $('#second_team_member_phone').on('keyup', function() {
            var coun = $(this).val();
            if (coun.length > 0) {
                second_team_member_phone = 1;
                $('#second_team_member_phone').css({
                    'border': "1px solid silver"
                })

                verify_final();

            } else {
                $('#final').attr('disabled');
                $('#final').text('disabled');
                $('#second_team_member_phone').css({
                    'border': "1px solid red"
                })
            }
        })


//        $('#third_team_member_name').on('keyup', function() {
//            var coun = $(this).val();
//            if (coun.length > 0) {
//                third_team_member_name = 1;
//                $('#third_team_member_name').css({
//                    'border': "1px solid silver"
//                })
//
//                verify_final();
//
//            } else {
//                $('#final').attr('disabled');
//                $('#final').text('disabled');
//                $('#third_team_member_name').css({
//                    'border': "1px solid red"
//                })
//            }
//        })
//
//        $('#third_team_member_email').on('keyup', function() {
//            var coun = $(this).val();
//            if (coun.length > 0) {
//                third_team_member_email = 1;
//                $('#third_team_member_email').css({
//                    'border': "1px solid silver"
//                })
//
//                verify_final();
//
//            } else {
//                $('#final').attr('disabled');
//                $('#final').text('disabled');
//                $('#third_team_member_email').css({
//                    'border': "1px solid red"
//                })
//            }
//        })
//
//        $('#third_team_member_phone').on('keyup', function() {
//            var coun = $(this).val();
//            if (coun.length > 0) {
//                third_team_member_phone = 1;
//                $('#third_team_member_phone').css({
//                    'border': "1px solid silver"
//                })
//
//                verify_final();
//
//            } else {
//                $('#final').attr('disabled');
//                $('#final').text('disabled');
//                $('#third_team_member_phone').css({
//                    'border': "1px solid red"
//                })
//            }
//        })

         
        function verify_final() {
            if (this.second_team_member_name == 1 && this.second_team_member_email == 1 && this.second_team_member_phone ==
                1) {
                $('#final').text('submit');
                $('#final').removeAttr('disabled');

            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('client-site.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\wamp64\www\over the wall - laravel\resources\views/auth/register.blade.php ENDPATH**/ ?>